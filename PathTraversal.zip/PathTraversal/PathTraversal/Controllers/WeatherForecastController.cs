using Microsoft.AspNetCore.Mvc;

namespace PathTraversal.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private readonly ILogger<WeatherForecastController> _logger;

        public WeatherForecastController(ILogger<WeatherForecastController> logger)
        {
            _logger = logger;
        }

        [HttpGet(Name = "GetWeatherForecast")]
        public async Task<IActionResult> Get(string documentId)
        {
            string filePath = Path.Join("documents/", documentId);
            try
            {
                var stream = new StreamReader(filePath);
                return File(stream.BaseStream, "application/octet-stream");
            }
            catch (Exception)
            {
                return NotFound();
            }
        }
    }
}