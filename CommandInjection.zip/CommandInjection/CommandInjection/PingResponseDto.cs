﻿namespace CommandInjection
{
    public class PingResponseDto
    {
        public string Response { get; set; }
    }
}
