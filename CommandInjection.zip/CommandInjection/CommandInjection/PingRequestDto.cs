﻿namespace CommandInjection
{
    public class PingRequestDto
    {
        public string IpAddress { get; set; }
    }
}
