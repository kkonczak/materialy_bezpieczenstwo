using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace CommandInjection.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class PingController : ControllerBase
    {
        private readonly ILogger<PingController> _logger;

        public PingController(ILogger<PingController> logger)
        {
            _logger = logger;
        }

        [HttpPost(Name = "Ping")]
        public PingResponseDto Post(PingRequestDto request)
        {
            var process = new Process();
            process.StartInfo.FileName = $"cmd";
            process.StartInfo.Arguments = $"/c ping {request.IpAddress}";
            process.StartInfo.RedirectStandardOutput = true;
            //process.StartInfo.UseShellExecute = false;
            process.Start();

            var response = process.StandardOutput.ReadToEnd();
            return new PingResponseDto() { Response = response };
        }
    }
}