import { Component, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-xss',
  templateUrl: './xss.component.html'
})
export class XssComponent {
  public name: string|any = "";

  constructor(private route: ActivatedRoute, private sanitizer: DomSanitizer) {
  }
   
  ngOnInit() {
    this.route.queryParams
      .subscribe(params => {
        this.name = this.sanitizer.bypassSecurityTrustHtml(params.name);
        
      });
  }

}
