import { Component, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-super-ping',
  templateUrl: './super-ping.component.html'
})
export class SuperPingComponent {
  public ipAddress: string = "";
  public isLoading: boolean = false;
  public result: string = "";

  constructor(private http: HttpClient, @Inject('BASE_URL') private baseUrl: string) {

  }

  runPing() {
    if (!/^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$/.test(this.ipAddress)) {
      alert("Nieprawidłowy adres IP!");
      return;
    }

    this.isLoading = true;
    this.http.post<PingResponse>(
      this.baseUrl + 'ping',
      {
        IpAddress: this.ipAddress
      })
      .subscribe(result => {
        this.result = result.response;
        console.log(result);
        this.isLoading = false;
      }, error => {
        console.error(error);
        this.isLoading = false;
      });
  }
}

interface PingResponse {
  response: string;
}
